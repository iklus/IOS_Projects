//
//  Klus_Poject5Tests.m
//  Klus_Poject5Tests
//
//  Created by Ivan Klus on 10/30/14.
//  Copyright (c) 2014 University of Cincinnati. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Klus_Poject5Tests : XCTestCase

@end

@implementation Klus_Poject5Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
