//
//  Contact.m
//  Klus_Poject5
//
//  Created by Ivan Klus on 10/30/14.
//  Copyright (c) 2014 University of Cincinnati. All rights reserved.
//

#import "Contact.h"

@implementation Contact

@end
