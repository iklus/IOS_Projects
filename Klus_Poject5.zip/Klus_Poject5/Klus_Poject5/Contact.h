//
//  Contact.h
//  Klus_Poject5
//
//  Created by Ivan Klus on 10/30/14.
//  Copyright (c) 2014 University of Cincinnati. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Contact : NSObject
// define both data and methods of the class.

// Data:
// first name
@property NSString* firstName;
// last name
@property NSString* lastName;
// email
@property NSString* emailAddress;

// Methods:



@end
