//
//  AppDelegate.h
//  Klus_Project1
//
//  Created by Ivan Klus on 8/28/14.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
