//
//  ViewController.m
//  Klus_Project1
//
//  Created by Ivan Klus on 8/28/14.
//
//

#import "ViewController.h"

@implementation ViewController
@synthesize txtName;
@synthesize helloText;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [txtName setDelegate:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)displayGreeting {
    // Clears Greeting
    helloText.text = @"Hello!";
    // Dismiss the keyboard
    txtName.text = nil;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    // Dismiss the keyboard
    [txtName resignFirstResponder];
    // Retrieve text from the textbox and put it in the label.
    NSString* userMessage=[txtName text];
    [helloText setText:[NSString stringWithFormat:@"Hello %@!",userMessage]];
    return true;
}

@end
