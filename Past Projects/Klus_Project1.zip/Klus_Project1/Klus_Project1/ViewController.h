//
//  ViewController.h
//  Klus_Project1
//
//  Created by Ivan Klus on 8/28/14.
//
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate>


@property (weak, nonatomic) IBOutlet UITextField *txtName;

- (IBAction)displayGreeting;

@property (weak, nonatomic) IBOutlet UILabel *helloText;


@end
