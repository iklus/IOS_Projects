//
//  Klus_Project1Tests.m
//  Klus_Project1Tests
//
//  Created by Ivan Klus on 8/28/14.
//
//

#import <XCTest/XCTest.h>

@interface Klus_Project1Tests : XCTestCase

@end

@implementation Klus_Project1Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
