//
//  ViewController.m
//  Klus_Project4
//
//  Created by Ivan Klus on 10/7/14.
//  Copyright (c) 2014 University of Cincinnati. All rights reserved.
//

#import "ViewController.h"
#define TURNS 3

@interface ViewController ()
@end

@implementation ViewController
@synthesize lblResult;
@synthesize correctImage, incorrectImage;


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    player = [AVAudioPlayer alloc];
    
    
    NSBundle* appBundle = [NSBundle mainBundle];
    
    notesCollection =[appBundle pathsForResourcesOfType:@"mp3" inDirectory:nil];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) resetGame{
    turnCounter = 0;
    score = 0;
    correctAnswers = 0;
}

- (IBAction)startGame {
    [self resetGame];
    [self playGame];
}

- (IBAction)checkAnswer:(UIButton *)sender {
    NSString* userSelection = [[sender titleLabel]text];
    
    userSelection = [userSelection stringByAppendingString:@".mp3"];
    
    [UIView beginAnimations:nil context:nil];
    
    [UIView setAnimationDuration:4.0];
    
    if ([userSelection isEqualToString:randomNote]) {
        [lblResult setText:@"Correct Answer"];
        [correctImage setAlpha:1.0];
        correctAnswers++;
        
    } else {
        [lblResult setText:@"Incorrect Answer"];
        [incorrectImage setAlpha:1.0];
        
    }
    [UIView commitAnimations];
    
    [self performSelector:@selector(playGame) withObject:nil afterDelay:4.0];
}

- (void) resetTurn{
    [lblResult setText:@" "];
    [correctImage setAlpha:0.0];
    [incorrectImage setAlpha:0.0];
}


- (void) playGame{
    turnCounter++;
    
    [self resetTurn];
    
    if (turnCounter <= TURNS) {
        
        int randomIndex = arc4random()%[notesCollection count];
        
        NSString* filePath = [notesCollection objectAtIndex:randomIndex];
        
        randomNote = [filePath lastPathComponent];
        
        NSURL* fileURL = [NSURL fileURLWithPath:filePath];
        
        player=[player initWithContentsOfURL:fileURL error:nil];
        
        [player play];
        
        NSLog(@"Random File Path %@",fileURL);
    } else {
        
        score = 100*(correctAnswers/TURNS);
        
        NSString* alertMessage = [NSString stringWithFormat:@"You got %d%% correct! Press Start Game to play again.",score];
    
        UIAlertView* alert = [UIAlertView alloc];
        alert = [alert initWithTitle:@"Game Over!" message:alertMessage delegate:nil cancelButtonTitle:@"Okay." otherButtonTitles:nil, nil];
        
        [alert show];
        
        [lblResult setText:@"Game Over!"];
        
        NSUserDefaults* sharedObject= [NSUserDefaults standardUserDefaults];
        
        [sharedObject setFloat:gamesPlayed forKey:@"gamesPlayed"];
        [sharedObject setFloat:highScore forKey:@"highScore"];
        [sharedObject setFloat:lastScore forKey:@"lastScore"];

        
    }
}




@end
