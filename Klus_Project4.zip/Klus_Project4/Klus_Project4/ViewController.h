//
//  ViewController.h
//  Klus_Project4
//
//  Created by Ivan Klus on 10/7/14.
//  Copyright (c) 2014 University of Cincinnati. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController : UIViewController
{
    // Define a player
    AVAudioPlayer* player;
    NSArray* notesCollection;
    NSString* randomNote;
    int turnCounter;
    int score;
    int correctAnswers;
    float highScore;
    float gamesPlayed;
    float lastScore;
}

- (IBAction)startGame;

- (IBAction)checkAnswer:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet UILabel *lblResult;

@property (weak, nonatomic) IBOutlet UIImageView *correctImage;

@property (weak, nonatomic) IBOutlet UIImageView *incorrectImage;


@end
