//
//  StatsViewController.h
//  Klus_Project4
//
//  Created by Ivan Klus on 10/30/14.
//  Copyright (c) 2014 University of Cincinnati. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StatsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *numberOfGameslbl;

@property (weak, nonatomic) IBOutlet UILabel *highScorelbl;

@property (weak, nonatomic) IBOutlet UILabel *lastScorelbl;

@end
