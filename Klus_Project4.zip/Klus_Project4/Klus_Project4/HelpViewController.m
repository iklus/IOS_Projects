//
//  HelpViewController.m
//  Klus_Project4
//
//  Created by Ivan Klus on 10/7/14.
//  Copyright (c) 2014 University of Cincinnati. All rights reserved.
//

#import "HelpViewController.h"

@interface HelpViewController ()
    
@end

@implementation HelpViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    player=[AVAudioPlayer alloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)playSound:(UIButton *)sender {
    NSString* fileName = [[sender titleLabel]text];
    
    NSBundle* appBundle = [NSBundle mainBundle];
    
    NSString* filePath = [appBundle pathForResource:fileName ofType:@"mp3"];
    
    NSURL* fileURL = [NSURL fileURLWithPath:filePath];
    
    player=[player initWithContentsOfURL:fileURL error:nil];
    
    [player play];
    
}
@end
