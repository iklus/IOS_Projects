//
//  Klus_Project4Tests.m
//  Klus_Project4Tests
//
//  Created by Ivan Klus on 10/7/14.
//  Copyright (c) 2014 University of Cincinnati. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Klus_Project4Tests : XCTestCase

@end

@implementation Klus_Project4Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
